window.SMAA_BUILD = 12;
